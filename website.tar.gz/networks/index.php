<?php
	//Include database connection details
	require_once('config.php');	

	echo("
<!DOCTYPE HTML>
<html lang='en'>
	<head>
		<title>Network Engineering</title>
		<meta http-equiv='content-type' content='text/html; charset=utf-8' />
		<meta name='description' content='' />
		<meta name='keywords' content='' />
		<link href='http://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,400,400italic' rel='stylesheet' type='text/css' />
		<!--[if lte IE 8]><script src='css/ie/html5shiv.js'></script><![endif]-->
		<script src='jquery.min.js'></script>
		<script src='skel.min.js'></script>
		<script src='init.js'></script>
		<script src='if_gmap.js'></script>
		
		<script src='https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&libraries=visualization'></script>
		<noscript>
			<link rel='stylesheet' href='css/skel-noscript.css' />
			<link rel='stylesheet' href='css/style.css' />
			<link rel='stylesheet' href='css/style-wide.css' />
		</noscript>
		<!--[if lte IE 8]><link rel='stylesheet' href='css/ie/v8.css' /><![endif]-->
		<!--[if lte IE 9]><link rel='stylesheet' href='css/ie/v9.css' /><![endif]-->
		
		<script>
		
			// Adding 500 Data Points
			var map, pointarray, heatmap;

			var taxiData = [
				//   new google.maps.LatLng(17.510522, 78.140720),
				//   
				//   new google.maps.LatLng(17.510829, 78.140636),
				//   new google.maps.LatLng(17.510843, 78.141325)
				");
				
				$essid = $_GET["essid"];
				if($essid){
					$qry = "SELECT latitude, longitude, avg(mui) from device_data d, device_info i where i.device_id = d.ap_id and i.essid = $essid GROUP BY ap_id;";
					$result = mysql_query($qry);
					$result = mysql_query($qry);
					while($row = mysql_fetch_array($result)) {
						echo "{location: new google.maps.LatLng($row[0],$row[1]), weight: $row[2]},";
					}
	
				}
				else {
					$essid = "IITH";
					$qry = 'SELECT latitude, longitude, avg(mui) as mui_final from device_data d, device_info i where i.device_id = d.ap_id and i.essid = "IITH" GROUP BY ap_id';
					$result = mysql_query($qry);
					while($row = mysql_fetch_array($result)) {
						echo "{location: new google.maps.LatLng($row[0],$row[1]), weight: $row[2]},";
					}
				}
// 				{location: new google.maps.LatLng(17.510522, 78.140720), weight: 10},
// 				{location: new google.maps.LatLng(17.510829, 78.140636), weight: 8}, 								
				echo ("
			];
	
			function initialize() {
				var mapOptions = {
					zoom: 18,
					center: new google.maps.LatLng(17.509617, 78.140325),
					mapTypeId: google.maps.MapTypeId.MAP
				};

				map = new google.maps.Map(document.getElementById('map-canvas'),
				mapOptions);

				var pointArray = new google.maps.MVCArray(taxiData);

				heatmap = new google.maps.visualization.HeatmapLayer({
					data: pointArray
				});

				heatmap.setMap(map);
			}

			function toggleHeatmap() {
				heatmap.setMap(heatmap.getMap() ? null : map);
			}

			function changeGradient() {
				var gradient = [
					'rgba(0, 255, 255, 0)',
					'rgba(0, 255, 255, 1)',
					'rgba(0, 191, 255, 1)',
					'rgba(0, 127, 255, 1)',
					'rgba(0, 63, 255, 1)',
					'rgba(0, 0, 255, 1)',
					'rgba(0, 0, 223, 1)',
					'rgba(0, 0, 191, 1)',
					'rgba(0, 0, 159, 1)',
					'rgba(0, 0, 127, 1)',
					'rgba(63, 0, 91, 1)',
					'rgba(127, 0, 63, 1)',
					'rgba(191, 0, 31, 1)',
					'rgba(255, 0, 0, 1)'
				]
				heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
			}

			function changeRadius() {
				heatmap.set('radius', heatmap.get('radius') ? null : 75);
			}

			function changeOpacity() {
				heatmap.set('opacity', heatmap.get('opacity') ? null : 0.2);
			}

			google.maps.event.addDomListener(window, 'load', initialize);

		</script>
		
		
	</head>
	<body onload='initialize();if_gmap_init();'>

		<!-- Header -->
			<section id='header' class='dark'>
				<header>
					<h1>Welcome to Raspberry-Pi Monitoring System</h1>
					<p>A project at IIT Hyderabad </p>
				</header>
				<footer>
					<a href='admin_panel' class='button scrolly'>Admin_panel</a>
					<a href='#first' class='button scrolly'>Make Heat Map</a>
				</footer>
			</section>
			
		<!-- First 
			<section id='first' class='main'>
				<header>
					<div class='container'>
						<h2>Add a new Device</h2> 
						</div>
				</header>
				
				<div class='content dark style2'>
					<div class='container'>
						<div class='row'>
							<div class='2u'>
								<section>
									<form method='post' action='add.php'>
										<div class='row'>
											<div class='12u'>
												Longitude
												<input class='text' type='text' value='120.994260' name='longval' id='longval' />
											</div>
										</div>
										<div class='row'>
											<div class='12u'>
												Latitude
												<input class='text' type='text' value='14.593999' name='latval' id='latval' />
											</div>
										</div>
										<div class='row'>
											<div class='12u'>
												<input type=button  class='button' value='Jump to location' onclick='if_gmap_loadpicker();'>
											</div>
										</div>
										
										<div class='row'>
											<div class='12u'>
											<div class='select'>
												<select name='device' id='device'>
													<option value=''>Choose a device</option>
													<option value='1'>Access Point</option>
													<option value='2'>Raspberry-Pi</option>
												</select>
											</div>
											</div>
										</div>
										
										<div class='row'>
											<div class='12u'>
												<input class='text' type='text' name='mac' id='mac' value='' placeholder='Mac ID' />
											</div>
										</div>
										
										<div class='row'>
											<div class='12u'>
												<input class='text' type='text' name='freq' id='freq' value='' placeholder='Frequency' />
											</div>
										</div>
										
										<div class='row'>
											<div class='12u'>
												<input class='text' type='text' name='essid' id='essid' value='' placeholder='Essid' />
											</div>
										</div>
										<div class='row'>
											<div class='12u'>
												<input type='submit' class='button' value='Add Device' />
											</div>
										</div>
									</form>
									
								</section>
							</div>
							<div class='10u'>
								<section>
								<div id='mapitems' style='width: 100%; height: 560px'></div>
								</section>
							</div>
						</div>
					</div>
				</div>
							
						
					
				
			</section>
-->
		<!-- Second -->
			<section id='first' class='main'>
				<header>
					<div class='container'>
						<h2>See the Heat Map below</h2>
					</div>
				</header>
				<div class='content dark style2'>
					<div class='container'>
						<div class='row'>
							<div class='12u'>
								<p align=\"justify\"> Draw heat map for <a href='index.php?essid=\"IITH-1\"'>IITH-1</a>,  <a href='index.php?essid=\"IITH\"'>IITH</a>,  <a href='index.php?essid=\"IITH-Guest\"'>IITH-Guest</a>.<p></p>
								Currently showing for $essid. :)
								</p>
								<div id='panel'>
									<button class='button' onclick='toggleHeatmap()'>Toggle Heatmap</button>
									<button class='button' onclick='changeGradient()'>Change gradient</button>
									<button class='button' onclick='changeRadius()'>Toggle between APs and their signal strength</button>
									<button class='button' onclick='changeOpacity()'>Change opacity</button>
								</div>
								<div id='map-canvas' style='width:100%; height: 560px'>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			
		<!-- Footer -->
			<section id='footer'>
				<ul class='icons'>
					<li><a href='#' class='fa fa-twitter solo'><span>Twitter</span></a></li>
					<li><a href='#' class='fa fa-facebook solo'><span>Facebook</span></a></li>
					<li><a href='#' class='fa fa-google-plus solo'><span>Google+</span></a></li>
					<li><a href='#' class='fa fa-dribbble solo'><span>Dribbble</span></a></li>
					<li><a href='#' class='fa fa-github solo'><span>GitHub</span></a></li>
				</ul>
				<div class='copyright'>
					<ul class='menu'>
						<li>&copy;2014 IIT Hyderabad. All rights reserved.</li>
						<li>Assignment by <a href='https://www.facebook.com/D3bUGer'>Deepak Bhardwaj</a> and <a href='https://www.facebook.com/vikash0207'>Vikash Kumar</a>  </li>
					</ul>
				</div>
			</section>

	</body>
</html>

")	;
?> 
