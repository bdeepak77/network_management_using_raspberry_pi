<?php
	//Include database connection details
	require_once('config.php');	


	
	$longi = doubleval($_POST['longval']);
	$lat = doubleval($_POST['latval']);
	$mac = $_POST['mac'];
	$freq = floatval($_POST['freq']);
	$device = intval($_POST['device']);
	$essid = $_POST['essid'];
	
	
	echo "<br>".$longi;
	echo "<br>".$lat;
	echo "<br>".$device;
	echo "<br>".$mac;
	
	if($longi != null and $lat != null and $mac != null and $device != null){
		$qry = "INSERT INTO device_info (mac, essid, frequency, latitude, longitude, device) VALUES ('$mac', '$essid', $freq, $lat, $longi, $device)";
		$result = @mysql_query($qry);	
	
		echo $qry;
		if($result) {	
			echo "<br> Device Added.";
		}
		else {
			echo"<br> query failed";
		}
	}
	else {
		echo "<br> please fill All the information ";
	}
	
	header( "refresh:2; url = index.php" );

?> 
