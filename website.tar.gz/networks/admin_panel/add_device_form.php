<?php
	//Include database connection details
	require_once('../config.php');	

	session_start();

	$longi = doubleval($_POST['longval']);
	$lat = doubleval($_POST['latval']);
	$mac = $_POST['mac'];
	$freq = floatval($_POST['freq']);
	$device = intval($_POST['device']);
	$essid = $_POST['essid'];
	
	if(isset($_SESSION['sess_user_id']) ){
		if($longi != null and $lat != null and $mac != null and $device != null){
			$qry = "INSERT INTO device_info (mac, essid, frequency, latitude, longitude, device) VALUES ('$mac', '$essid', $freq, $lat, $longi, $device)";
			$result = @mysql_query($qry);	
			
			if($result) {
				$qry2 = "Select device_id from device_info where mac like \"$mac\";";
				$result2 = @mysql_query($qry2);
				
				while($row = mysql_fetch_array($result2)) {
					$device_id = $row['device_id'];
				}
				if($device == 2)
					$text= "Please note down device id. You need to insert in Raspberry-Pi.";
				else
					$text= "Thanks for registering Access Point";
				header( "Location: add_device.php?notice=Device added Successfully. Device Id of your device is $device_id. $text");
			}
			else {
				header( "Location: add_device.php?notice=Query Failed. Please try again. ");
			}
		}
		else {
			header( "Location: add_device.php?notice=Please fill All the information ");
		}
	}
	else {
		header('Location: index.html');
	}
?> 
