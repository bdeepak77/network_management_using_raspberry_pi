<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	if( !isset($_SESSION['sess_user_id']) ){
		header('Location: index.html');
	}
	else {
		$qry_ap = "select device_id, essid, mac, frequency from device_info where device = 1";
		$result_ap = @mysql_query($qry_ap);	
	
		$count_access_points = mysql_num_rows($result_ap);
		
		$qry_pi = "select device_id from device_info where device = 2";
		$result_pi = @mysql_query($qry_pi);	
	
		$count_respberry_pi = mysql_num_rows($result_pi);
		
		$qry1 = "select device_id, essid, mac from device_info where device = 1 and device_id NOT IN (select ap_id from device_data where (TIMESTAMPDIFF( MINUTE, date_time, NOW() )) < 6  group by ap_id)";
		$result1 = mysql_query($qry1);	
	
		$not_access_points = mysql_num_rows($result1);
		
		$qry2 = "select device_id, essid, mac from device_info where device = 2 and device_id NOT IN (select distinct pi_id from device_data where (TIMESTAMPDIFF( MINUTE, date_time, NOW() )) < 6 group by pi_id)";
		$result2 = @mysql_query($qry2);	
	
		$not_raspberry_pi = mysql_num_rows($result2);
		
		$ap_percent_not = round($not_access_points/$count_access_points*100,1);
		$ap_percent = 100 - $ap_percent_not;
		
		$pi_percent_not = round($not_raspberry_pi/$count_respberry_pi*100,1);
		$pi_percent = 100 - $pi_percent_not;
	
		$qry_no_loc = "select device_id, essid, mac from device_info where (latitude is null or latitude = 0) and (longitude is null or longitude = 0)";
		$result_no_loc = @mysql_query($qry_no_loc);	
	
		$no_location = mysql_num_rows($result_no_loc);
		$loc_percent_not = round($no_location/($count_access_points+$count_respberry_pi)*100,1);
		$loc_percent = 100 - $loc_percent_not;
		
		$total_errors = $no_location + $not_access_points + $not_raspberry_pi;
		
		echo ("
<html lang=\"en\">
<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
	<title>Raspberry-Pi Monitoring System Admin Panel</title>

	<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"favicon.ico\" />

	<!-- bootstrap -->
	<link href=\"css/bootstrap/bootstrap.css\" rel=\"stylesheet\" />
	
	<link rel=\"stylesheet\" href=\"css/font-awesome-4.0.3/css/font-awesome.min.css\">
	<link rel=\"stylesheet\" href=\"css/jquery-ui.css\" />
	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/toastr.css\">
	
	<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\" />
	
	<script src='https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&libraries=visualization'></script>
		
	<script>
	
		// Adding 500 Data Points
		var map, pointarray, heatmap;

		var taxiData = [
			//   new google.maps.LatLng(17.510522, 78.140720),
			//   
			//   new google.maps.LatLng(17.510829, 78.140636),
			//   new google.maps.LatLng(17.510843, 78.141325)
			");
			
			$essid = $_GET["essid"];
			$custom = $_GET["custom"];
			$frequency = $_GET["frequency"];
			if(!$frequency)
				$frequency = 2.4;
				
			$down_freq = $frequency - 1;
			$up_freq = $frequency + 1;
			if($essid){
				$qry = "select device_id, latitude, longitude, avg(c.mui) from ( select b.pi_id, b.ap_id, a.m, b.token, mui from (select pi_id, ap_id, max(token) m from device_data group by pi_id, ap_id) as a natural join device_data b where b.token = a.m ) as c, device_info where device_id = c.ap_id and essid like $essid and frequency < $up_freq and frequency > $down_freq  group by c.ap_id;";
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result)) {
					if($custom && isset($_POST['chk-'.$row[0]]))
						echo "{location: new google.maps.LatLng($row[1],$row[2]), weight: $row[3]/10},";
					if(!$custom)
						echo "{location: new google.maps.LatLng($row[1],$row[2]), weight: $row[3]},";
				}

			}
			else {
				$essid = "'IITH'";
				$qry = "select device_id, latitude, longitude, avg(c.mui) from ( select b.pi_id, b.ap_id, a.m, b.token, mui from (select pi_id, ap_id, max(token) m from device_data group by pi_id, ap_id) as a natural join device_data b where b.token = a.m ) as c, device_info where device_id = c.ap_id and essid like $essid and frequency < $up_freq and frequency > $down_freq group by c.ap_id;";
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result)) {
					echo "{location: new google.maps.LatLng($row[1],$row[2]), weight: $row[3]},";
				}
			}
// 				{location: new google.maps.LatLng(17.510522, 78.140720), weight: 10},
			echo ("
		];

		function initialize() {
			var mapOptions = {
				zoom: 18,
				center: new google.maps.LatLng(17.509617, 78.140325),
				mapTypeId: google.maps.MapTypeId.MAP
			};

			map = new google.maps.Map(document.getElementById('map-canvas'),
			mapOptions);
			
			var pointArray = new google.maps.MVCArray(taxiData);

			heatmap = new google.maps.visualization.HeatmapLayer({
				data: pointArray
			});

			heatmap.setMap(map);
			 var opt = { minZoom: 18, maxZoom: 18 };
			map.setOptions(opt);
			
		}

		function toggleHeatmap() {
			heatmap.setMap(heatmap.getMap() ? null : map);
		}

		function changeGradient() {
			var gradient = [
				'rgba(0, 255, 255, 0)',
				'rgba(0, 255, 255, 1)',
				'rgba(0, 191, 255, 1)',
				'rgba(0, 127, 255, 1)',
				'rgba(0, 63, 255, 1)',
				'rgba(0, 0, 255, 1)',
				'rgba(0, 0, 223, 1)',
				'rgba(0, 0, 191, 1)',
				'rgba(0, 0, 159, 1)',
				'rgba(0, 0, 127, 1)',
				'rgba(63, 0, 91, 1)',
				'rgba(127, 0, 63, 1)',
				'rgba(191, 0, 31, 1)',
				'rgba(255, 0, 0, 1)'
			]
			heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
		}

		function changeRadius() {
			heatmap.set('radius', heatmap.get('radius') ? null : 100);
		}

		function changeOpacity() {
			heatmap.set('opacity', heatmap.get('opacity') ? null : 0.2);
		}

		google.maps.event.addDomListener(window, 'load', initialize);

	</script>
	
</head>
<body onload='initialize();'>

	<div id=\"loading\">
		<div>
			<div></div>
		    <div></div>
		    <div></div>
		</div>
	</div>

	<div id=\"wrapper\">
		<div id=\"top\">
			
			<div class=\"main-logo\">
				<h4 style=\"color:#fff;\">RPMS Admin Panel</h4>
			</div>
			
			<div class=\"m-nav\"><i class=\"fa fa-bars\"></i></div>

			<div class=\"profile-nav\">
				<ul>
					<li class=\"profile-user-info\">
						<a href=\"#\" onclick=\"return false;\">
							<b>Welcome, </b><span>");
							echo $_SESSION['sess_username'];
							echo ("</span> <i class=\"fa fa-user\"></i>
						</a>
					</li>
					<li>
						<a href=\"notification.php\" class=\"profile-badge-info\">
							<i class=\"fa fa-bolt\"></i> Notification
						</a>
						<span class=\"badge profile-badge blue\">$total_errors</span>
					</li>
					<li>
						<a href=\"logout.php\">
							<i class=\"fa fa-times-circle\"></i> Logout
						</a>
					</li>
				</ul>
			</div>

		</div> <!-- /top -->

		<div id=\"sidebar\">
			<div class=\"search\">
				<form action=\"search.php\" method=\"post\">
					<input type=\"search\" name=\"search\" id=\"search\" placeholder=\"Search database here...\">
					<i class=\"fa fa-search\"></i>
				</form>
			</div>
			<ul class=\"main-nav\">
				<li class=\"active\">
					<a href=\"#\" onclick=\"return false;\"><i class=\"fa fa-dashboard\"></i> Dashboard</a>
				</li>
				<li class=\"collapsible\">
					<a href=\"#\" onclick=\"return false;\"><i class=\"fa fa-info\"></i>Data Modification</a>
					<ul class=\"sub-menu\">
						<li><a href=\"add_device.php\"><i class=\"fa fa-plus-square\"></i>Add Device</a></li>
						<li><a href=\"add_location.php\"><i class=\"fa fa-location-arrow\"></i>Add location</a></li>
						<li><a href=\"change_location.php\"><i class=\"fa fa-level-up\"></i>Change location</a></li>
						<li><a href=\"delete_device.php\"><i class=\"fa fa-minus-square\"></i>Delete device</a></li>
					</ul>
				</li>
				<li><a href=\"notification.php\"><i class=\"fa fa-bolt\"></i> Notification</a></li>
				<li class=\"collapsible\">
					<a href=\"#\" onclick=\"return false;\"><i class=\"fa fa-gears\"></i>Settings</a>
					<ul class=\"sub-menu\">
						<li><a href=\"settings.php\"><i class=\"fa fa-exclamation\"></i>Change password</a></li>
						<li><a href=\"settings.php\"><i class=\"fa fa-tag\"></i>change username</a></li>
						<li><a href=\"settings.php\"><i class=\"fa fa-user\"></i>Add user</a></li>
						<li><a href=\"settings.php\"><i class=\"fa fa-minus-square\"></i>Delete user</a></li>
					</ul>
				</li>
			</ul>
		</div> <!-- /sidebar -->

		<div id=\"content\" class=\"clearfix\">

			<div class=\"header\">
				
				<h1 class=\"page-title\">Dashboard</h1>
				<div class=\"stats\">
					<div class=\"stat\" id=\"st-visits\">
						<div class=\"st-chart\">
							<span id=\"stats_visits\" values=\"$ap_percent, $ap_percent_not\"></span><br>
							$ap_percent_not%
						</div>
						<div class=\"st-detail\">
							$not_access_points<br><span>APs not respond</span>
						</div>
					</div> <!-- /stat -->
					<div class=\"stat\" id=\"st-users\">
						<div class=\"st-chart\">
							<span id=\"stats_users\" values=\"$pi_percent,$pi_percent_not\"></span><br>
							$pi_percent_not%
						</div>
						<div class=\"st-detail\">
							$not_raspberry_pi<br><span>PIs not respond</span>
						</div>
					</div> <!-- /stat -->
					<div class=\"stat\" id=\"st-users\">
						<div class=\"st-chart\">
							<span id=\"stats_orders\" values=\"$loc_percent,$loc_percent_not\"></span><br>
							$loc_percent_not%
						</div>
						<div class=\"st-detail\">
							$no_location<br><span>Device loc. not set</span>
						</div>
					</div> <!-- /stat -->
					<button class=\"btn btn-green\" onClick=\"window.location.reload()\"><i class=\"fa fa-refresh\"></i> Update</button>
				</div> <!-- /stats -->

			</div> <!-- /header -->

			<div class=\"breadcrumbs\">
				<i class=\"fa fa-dashboard\"></i> Admin panel <i class=\"fa fa-caret-right\"></i> Dashboard
			</div>

			<div class=\"wrp clearfix\">

				<div id=\"qn\">
						<button><a href=\"#\" onclick=\"toggleHeatmap()\"><i class=\"fa fa-toggle-left\"></i> Toggle Heatmap</a></button>
						<button><a href=\"#\" onclick=\"changeGradient()\"><i class=\"fa fa-dot-circle-o\"></i> Change Gradient</a></button>
						<button><a href=\"#\" onclick=\"changeRadius()\"><i class=\"fa fa-retweet\"></i> Toddle between APs and their signal strength</a></button>
						<button><a href=\"#\" onclick=\"changeOpacity()\"><i class=\"fa fa-adjust\"></i> Change opacity</a></button>
					
				</div>
				
				<div class=\"quick-nav\">
					<ul>
						<li class=\"qn-first\"><a href=\"#\" onclick=\"toggleHeatmap()\"><i class=\"fa fa-toggle-left\"></i> Toggle Heatmap</a></li>
						<li><a href=\"#\" onclick=\"changeGradient()\"><i class=\"fa fa-dot-circle-o\"></i> Change Gradient</a></li>
						<li><a href=\"#\" onclick=\"changeRadius()\"><i class=\"fa fa-retweet\"></i> Toddle between APs and their signal strength</a></li>
						<li><a href=\"#\" onclick=\"changeOpacity()\"><i class=\"fa fa-adjust\"></i> Change opacity</a></li>
					</ul>
				</div>

				<div class=\"fluid\">

					<div class=\"widget grid12\">
						<div class=\"widget-header\">
							<div class=\"widget-title\">
								<i class=\"fa fa-map-marker\"></i> Heatmap
							</div>
						</div>
						
						<div id=\"eTabs\">
							<ul class=\"etabs\">
							");
							$listing_qry = "select DISTINCT  essid, ROUND(frequency,0) as fe  from device_info where device = 1 and essid is not null and frequency is not null and frequency != 0 group by essid, frequency;";
							$result_listing = @mysql_query($listing_qry);
							while($row_list = mysql_fetch_assoc($result_listing))
							{
								if($row_list['fe'] < 2.5) 
									$freq = 2.4;
								else
									$freq = 5;
								echo "<li class=\"tab\"><a href=\"home.php?essid='{$row_list['essid']}'&frequency=$freq \">{$row_list['essid']}-$freq Ghz</a></li>";
							}
								echo ("<li class=\"tab\"><a href=\"#\">| Currently viewing <b>$essid - $frequency Ghz</b></a></li>
							</ul>
							<div class=\"tabsContent\">
								<div id='map-canvas' style='width:100%; height: 560px'></div>
							</div>
						</div>
					</div> <!-- /widget -->
					
				</div> <!-- /fluid -->
				
				
				<div class=\"fluid\">
					<div class=\"widget grid12\">
						<div class=\"widget-header\">
							<div class=\"widget-title\">
								<i class=\"fa fa-comments\"></i> View limited APs
							</div>
						</div> <!-- /widget-header -->
						<div class=\"widget-content pad20f\">
							<form  action=\"home.php?essid=$essid&frequency=$frequency&custom=1\" method=\"post\">
							
							<div class=\"custom-input\">
							 ");
							while($row4 = mysql_fetch_assoc($result_ap))
							{
								if( $row4['essid'] == str_replace("'", "", $essid)){
									if ( $row4['frequency'] < $up_freq and $row4['frequency'] > $down_freq) {
									echo   "<input type=\"checkbox\" id=\"chk-" .$row4['device_id']. "\" name=\"chk-" .$row4['device_id']. "\" ><label for=\"chk-". $row4['device_id'] . "\">". $row4['essid'] ."-". $row4['mac'] . "</label>";
									if($row4['essid']!="IITH-Guest")
											echo "&emsp; &emsp; &emsp;";
									else
										echo "&emsp;";
									}
								}
							}
								
							echo ("
								
							</div>
							<button class=\"btn btn-blue\" type=\"submit\">Submit</button>
							</form>		
						</div> <!-- /widget-content -->

					</div> <!-- /widget -->

				</div> <!-- /fluid -->
			</div> <!-- /wrp -->

		</div> <!-- /content -->
		<footer class=\"footer\">
			© 2014 IIT Hyderabad. All rights reserved.  
		</footer>

	</div> <!-- /wrapper -->


	<script type=\"text/javascript\" src=\"js/prefixfree.min.js\"></script>
	<script type=\"text/javascript\" src='js/jquery-1.10.2.min.js'></script>
	<script type=\"text/javascript\" src=\"js/jquery-ui.js\"></script>
	<script type=\"text/javascript\" src=\"js/bootstrap.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/excanvas.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.flot.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.flot.resize.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.sparkline.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.hashchange.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.easytabs.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/toastr.min.js\"></script>

	<script type=\"text/javascript\">

		$(window).load(function(){
			$('#loading').fadeOut(1000);

			toastr.options = {
			  \"closeButton\": true,
			  \"debug\": false,
			  \"positionClass\": \"toast-bottom-right\",
			  \"onclick\": null,
			  \"showDuration\": \"300\",
			  \"hideDuration\": \"1000\",
			  \"timeOut\": \"5000\",
			  \"extendedTimeOut\": \"1000\",
			  \"showEasing\": \"swing\",
			  \"hideEasing\": \"linear\",
			  \"showMethod\": \"fadeIn\",
			  \"hideMethod\": \"fadeOut\"
			}
			setTimeout(function(){
				toastr.info('<span style=\"color:#333;\">Welcome to Raspberry-Pi Monitoring System Admin Panel! With great power comes great responsibility.</span>');	
			},2000) ;");
			
			if(($not_access_points+$not_raspberry_pi+$no_location)==0){
				echo("	setTimeout(function(){
				toastr.info('<span style=\"color:#333;\">Everything is working fine. :)</span>');
				},3500) ;");
			}
			else {
				if($not_access_points != 0){
					echo(" setTimeout(function(){
						toastr.warning('<span style=\"color:#333;\">Following Access Points have not responded.<ul>");
					while($row1 = mysql_fetch_assoc($result1))
					{
						echo   "<li>" .$row1['essid']. " - ". $row1['mac'] . "</li>";
					}
					
					echo("</ul></span>');
				},3500) ; ");
				}
				if($not_raspberry_pi != 0){
					echo(" setTimeout(function(){
						toastr.warning('<span style=\"color:#333;\">Following Raspberry-Pi have not responded.<ul>");
					while($row2 = mysql_fetch_assoc($result2))
					{
						echo   "<li>" .$row2['essid']. " - ". $row2['mac'] . "</li>";
					}
					
					echo("</ul></span>');
				},4500) ; ");
				}
				if($no_location != 0){
					echo(" setTimeout(function(){
						toastr.warning('<span style=\"color:#333;\">Following Device locations are not available have not responded.<ul>");
					while($row3 = mysql_fetch_assoc($result_no_loc))
					{
						echo   "<li>" .$row3['essid']. " - ". $row3['mac'] . "</li>";
					}
					
					echo("</ul></span>');
				},5500) ; ");
				}				
			}

			echo("
		// $(document).ready(function(){

			$('.collapsible > a').click(function(){
				$(this).parent().toggleClass('open');
				if( $(this).parent().siblings().hasClass('open') ){
					$(this).parent().siblings().removeClass('open');
				}
			return false;
			}) // Collapsible


			// -------------------------- SPARKLINE miniCHARTS -----------------------------//

			$(\"#stats_visits\").sparkline('html',{
		        type: 'pie',
		        sliceColors: ['#499ac7','transparent'],
		        offset:-90,
		        tooltipClassname:'tooltip-sp',
		        disableHighlight:true
		    });
		    $(\"#stats_users\").sparkline('html',{
		        type: 'pie',
		        sliceColors: ['#37343b','transparent'],
		        offset:-90,
		        tooltipClassname:'tooltip-sp',
		        disableHighlight:true 
		    });
		    $(\"#stats_orders\").sparkline('html',{
		        type: 'pie',
		        sliceColors: ['#83a854','transparent'],
		        offset:-90,
		        tooltipClassname:'tooltip-sp',
		        disableHighlight:true
		    });

		    
		 

		}) // Ready.
	</script>
</body>
</html>
");

}
?>
