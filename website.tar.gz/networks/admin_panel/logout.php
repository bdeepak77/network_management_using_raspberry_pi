<?php
	session_start();
	
	if(isset($_SESSION['sess_user_id'])){
		unset($_SESSION['sess_user_id']);
		unset($_SESSION['sess_username']);
	}
	
	session_destroy();
	echo " You are successfully logged out";
	header( "refresh:2; url = ../index.php" );
?> 