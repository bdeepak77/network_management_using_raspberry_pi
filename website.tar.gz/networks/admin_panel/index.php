<?php

session_start();
	
	if( isset($_SESSION['sess_user_id']) ){
		header('Location: home.php');
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Raspberry-Pi Monitoring System Admin Panel</title>
	
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />

	<!-- bootstrap -->
    <link href="css/bootstrap/bootstrap.css" rel="stylesheet" />
    
    <link rel="stylesheet" href="css/font-awesome-4.0.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css" />
	
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	
	<script>
		var varname = '<?php echo $_SESSION['sess_user_id']; ?>';;
		console.log(varname);
	</script>
	
</head>
<body>
	<div id="loading">
		<div>
			<div></div>
		    <div></div>
		    <div></div>
		</div>
	</div>
	
		<div id="content" class="c-login clearfix">
			<div class="header">
					<a href="#"><h4 style="color:#fff;">RPMS Admin Panel</h4></a>
			</div> <!-- /header -->

			<div class="breadcrumbs">
				<i class="fa fa-key"></i> Login
			</div>
			
			<div class="widget-content">
				<form action="login.php" method="post">
					<input type="text" name="userid" placeholder="Email / username">
					<input type="password" name="pass" placeholder="Password">
					<input type="submit" class="btn btn-blue pull-right" value="Login">
				</form>
			</div>
		</div> <!-- /content -->
		<footer class="footer">
			©2014 IIT Hyderabad. All rights reserved.  
		</footer>

	</div> <!-- /wrapper -->

	<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	<script type="text/javascript">

		$(window).load(function(){
			$('#loading').fadeOut(1000);
		}) // Ready.
	</script>
</body>
</html>
