<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	$userid = $_POST['userid'];
	$pass = $_POST['pass'];

	if( !isset($_SESSION['sess_user_id']) ){
		
		if($userid != null and $pass != null){
			$qry = "SELECT user_name FROM users where user_id like \"$userid\" and password like \"$pass\"";
			$result = @mysql_query($qry);	
		
			// Mysql_num_row is counting table row
			$count=mysql_num_rows($result);
			
// 			echo "<br> $count";
			// If result matched $myusername and $mypassword, table row must be 1 row
			if($count==1){

			// Register $myusername, $mypassword and redirect to file "home.php"
				$userData = mysql_fetch_array($result, MYSQL_ASSOC);
				session_regenerate_id();
				$_SESSION['sess_user_id'] = $userid;
				$_SESSION['sess_username'] = $userData['user_name'];
				session_write_close();
				echo "Now you are Logged in as ";
				echo $_SESSION['sess_user_id'];
			}
			else {
				echo "Wrong Username or Password";
			}
		}
		else {
			echo "<br> please fill All the information ";
		}
	}
	else {
			echo "<br> Already logged in as ";
			echo $_SESSION['sess_user_id'];
	}
	
 	header('Location: home.php');

?> 
