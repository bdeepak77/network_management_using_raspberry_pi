<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	$new_user_name = $_POST['new_user_name'];
	echo "<br>". $new_user_name;
	if(isset($_SESSION['sess_user_id']) ){
		
		if($new_user_name != null){
			$qry = "SELECT user_name FROM users where user_id like \"".$_SESSION['sess_user_id']."\"";
			$result = mysql_query($qry);	
			
			// Mysql_num_row is counting table row
			$count=mysql_num_rows($result);
			
 			
			// If result matched $myusername and $mypassword, table row must be 1 row
			if($count==1){
				$qry2 = "UPDATE users SET username=\"$new_user_name\" where user_id like \"".$_SESSION['sess_user_id']."\"";
				$result2 = mysql_query($qry2);
				session_regenerate_id();
				$_SESSION['sess_username'] = $new_user_name;
				session_write_close();
				header('Location: settings.php?notice=Username Changed');
				
			}
			else {
				header('Location: logout.php');
			}
		}
		else {
			header('Location: settings.php?notice=Please enter all the details.');
		}
	}
	else {
		header('Location: index.html');
	}
?> 
