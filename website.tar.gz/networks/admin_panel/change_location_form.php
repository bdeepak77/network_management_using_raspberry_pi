<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	$longval = $_POST['longval'];
	$latval = $_POST['latval'];
	$device_id = $_POST['selected_device_id'];
	
	if(isset($_SESSION['sess_user_id']) ){
		
		if($longval != null and $latval != null and $device_id != null){
			$qry_no_loc = "select device_id from device_info where device_id = $device_id";
			$result_no_loc = @mysql_query($qry_no_loc);	
		
			$no_location = mysql_num_rows($result_no_loc);
			if($no_location == 1){
				$qry2 = "UPDATE device_info SET latitude=\"$latval\", longitude=\"$longval\" where device_id = $device_id";
				$result2 = mysql_query($qry2);
				header('Location: change_location.php?notice=Location updated');
				
			}
			else {
				header('Location: change_location.php?notice=Location of selected device is already set by some other user.');
			}
		}
		else {
			header('Location: change_location.php?notice=Please enter all the details.');
		}
	}
	else {
		header('Location: index.html');
	}
?> 
