<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	$old_pass = $_POST['old_pass'];
	$new_pass = $_POST['new_pass'];

	if(isset($_SESSION['sess_user_id']) ){
		
		if($old_pass != null and $new_pass != null){
			$qry = "SELECT user_name FROM users where user_id like \"".$_SESSION['sess_user_id']."\" and password like \"$old_pass\"";
			$result = mysql_query($qry);	
		
			// Mysql_num_row is counting table row
			$count=mysql_num_rows($result);
			
 			echo "<br> $count";
			// If result matched $myusername and $mypassword, table row must be 1 row
			if($count==1){
				$qry2 = "UPDATE users SET password=\"$new_pass\" where user_id like \"".$_SESSION['sess_user_id']."\" and password like \"$old_pass\"";
				$result2 = mysql_query($qry2);
				header('Location: settings.php?notice=Password Changed');
				
			}
			else {
				header('Location: settings.php?notice=Invalid old password');
			}
		}
		else {
			header('Location: settings.php?notice=Please enter all the details.');
		}
	}
	else {
		header('Location: index.html');
	}
?> 
