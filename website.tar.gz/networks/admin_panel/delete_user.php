<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	$password = $_POST['password'];

	if(isset($_SESSION['sess_user_id']) ){
		
		if($password != null){
			$qry = "SELECT user_id FROM users where user_id like \"".$_SESSION['sess_user_id']."\" and password like \"$password\"";
			$result = mysql_query($qry);	
		
			// Mysql_num_row is counting table row
			$count=mysql_num_rows($result);
			
			// If result matched $myusername and $mypassword, table row must be 1 row
			if($count==1){
				$qry_check = "select new_user_id from users_added where new_user_id like \"".$_SESSION['sess_user_id']."\"";
				$result_check = @mysql_query($qry_check);	
				
				$count_check = mysql_num_rows($result_check);
				
				if( $count_check == 0){
					$qry2 = "SELECT new_user_id from users_added";
					$result2 = mysql_query($qry2);
					while($row = mysql_fetch_array($result2)) {
						if(isset($_POST['chk-'.$row[0]])){
							$qry_final = "Delete FROM users where user_id like \"$row[0]\"";
							$result_final = mysql_query($qry_final);
							
							$qry_final2 = "Delete FROM users_added where user_id like \"$row[0]\" or new_user_id like \"$row[0]\"";
							$result_final2 = mysql_query($qry_final2);
						}
					}
				}
				else {
					$qry2 = "SELECT new_user_id from users_added where user_id like \"".$_SESSION['sess_user_id']."\"";
					$result2 = mysql_query($qry2);
					while($row = mysql_fetch_array($result2)) {
						if(isset($_POST['chk-'.$row[0]])){
							$qry_final = "Delete FROM users where user_id like \"$row[0]\"";
							$result_final = mysql_query($qry_final);
							$qry_final2 = "Delete FROM users_added where user_id like \"$row[0]\" or new_user_id like \"$row[0]\"";
							$result_final2 = mysql_query($qry_final2);
						}
					}
				}
				
				header('Location: settings.php?notice=Selected Users Deleted Suceessfully.');
				
			}
			else {
				header('Location: settings.php?notice=Please enter correct password');
			}
		}
		else {
			header('Location: settings.php?notice=Please enter all the details.');
		}
	}
	else {
		header('Location: index.html');
	}
?> 
