<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	$user_id = $_POST['user_id'];
	$username = $_POST['username'];
	$password = $_POST['password'];

	if(isset($_SESSION['sess_user_id']) ){
		
		if($user_id != null and $password != null and $username != null){
			$qry = "SELECT user_id FROM users where user_id like \"$user_id\"";
			$result = mysql_query($qry);	
		
			// Mysql_num_row is counting table row
			$count=mysql_num_rows($result);
			
			// If result matched $myusername and $mypassword, table row must be 1 row
			if($count==0){
				$qry2 = "Insert into users values(\"$user_id\",\"$password\",\"$username\")";
				$result2 = mysql_query($qry2);
				$qry3 = "Insert into users_added values(\"".$_SESSION['sess_user_id']."\",\"$user_id\")";
				$result3 = mysql_query($qry3);
				header('Location: settings.php?notice=User Added Suceessfully.');
				
			}
			else {
				header('Location: settings.php?notice=User already exists. Please try some other user_id');
			}
		}
		else {
			header('Location: settings.php?notice=Please enter all the details.');
		}
	}
	else {
		header('Location: index.html');
	}
?> 
