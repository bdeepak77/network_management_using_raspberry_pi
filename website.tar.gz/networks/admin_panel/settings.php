<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	if( !isset($_SESSION['sess_user_id']) ){
		header('Location: index.html');
	}
	else {
		$qry_ap = "select device_id, essid,  mac from device_info where device = 1";
		$result_ap = @mysql_query($qry_ap);	
	
		$count_access_points = mysql_num_rows($result_ap);
		
		$qry_pi = "select device_id from device_info where device = 2";
		$result_pi = @mysql_query($qry_pi);	
	
		$count_respberry_pi = mysql_num_rows($result_pi);
		
		$qry1 = "select device_id, essid, mac from device_info where device = 1 and device_id NOT IN (select ap_id from device_data where (TIMESTAMPDIFF( MINUTE, date_time, NOW() )) < 6  group by ap_id)";
		$result1 = mysql_query($qry1);	
	
		$not_access_points = mysql_num_rows($result1);
		
		$qry2 = "select device_id, essid, mac from device_info where device = 2 and device_id NOT IN (select distinct pi_id from device_data where (TIMESTAMPDIFF( MINUTE, date_time, NOW() )) < 6 group by pi_id)";
		$result2 = @mysql_query($qry2);	
	
		$not_raspberry_pi = mysql_num_rows($result2);
		
		$ap_percent_not = round($not_access_points/$count_access_points*100,1);
		$ap_percent = 100 - $ap_percent_not;
		
		$pi_percent_not = round($not_raspberry_pi/$count_respberry_pi*100,1);
		$pi_percent = 100 - $pi_percent_not;
	
		$qry_no_loc = "select device_id, essid, mac from device_info where (latitude is null or latitude = 0) and (longitude is null or longitude = 0)";
		$result_no_loc = @mysql_query($qry_no_loc);	
	
		$no_location = mysql_num_rows($result_no_loc);
		
		$loc_percent_not = round($no_location/($count_access_points+$count_respberry_pi)*100,1);
		$loc_percent = 100 - $loc_percent_not;
		
		$total_errors = $no_location + $not_access_points + $not_raspberry_pi;
		
		echo ("
<html lang=\"en\">
<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
	<title>Raspberry-Pi Monitoring System Admin Panel</title>

	<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"favicon.ico\" />

	<!-- bootstrap -->
	<link href=\"css/bootstrap/bootstrap.css\" rel=\"stylesheet\" />
	
	<link rel=\"stylesheet\" href=\"css/font-awesome-4.0.3/css/font-awesome.min.css\">
	<link rel=\"stylesheet\" href=\"css/jquery-ui.css\" />
	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/toastr.css\">
	
	<script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&libraries=visualization\"></script>
	<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\" />
	<script src=\"../if_gmap.js\"></script
	
</head>
<body  onload=\"if_gmap_init();\">

	<div id=\"loading\">
		<div>
			<div></div>
		    <div></div>
		    <div></div>
		</div>
	</div>

	<div id=\"wrapper\">
		<div id=\"top\">
			
			<div class=\"main-logo\">
				<h4 style=\"color:#fff;\">RPMS Admin Panel</h4>
			</div>
			
			<div class=\"m-nav\"><i class=\"fa fa-bars\"></i></div>

			<div class=\"profile-nav\">
				<ul>
					<li class=\"profile-user-info\">
						<a href=\"#\" onclick=\"return false;\">
							<b>Welcome, </b><span>");
							echo $_SESSION['sess_username'];
							echo ("</span> <i class=\"fa fa-user\"></i>
						</a>
					</li>
					<li>
						<a href=\"notification.php\" class=\"profile-badge-info\">
							<i class=\"fa fa-bolt\"></i> Notification
						</a>
						<span class=\"badge profile-badge blue\">$total_errors</span>
					</li>
					<li>
						<a href=\"logout.php\">
							<i class=\"fa fa-times-circle\"></i> Logout
						</a>
					</li>
				</ul>
			</div>

		</div> <!-- /top -->

		<div id=\"sidebar\">
			<div class=\"search\">
				<form action=\"search.php\" method=\"post\">
					<input type=\"search\" name=\"search\" id=\"search\" placeholder=\"Search database here...\">
					<i class=\"fa fa-search\"></i>
				</form>
			</div>
			<ul class=\"main-nav\">
				<li >
					<a href=\"home.php\" ><i class=\"fa fa-dashboard\"></i> Dashboard</a>
				</li>
				<li class=\"collapsible\">
					<a href=\"#\" onclick=\"return false;\"><i class=\"fa fa-info\"></i>Data Modification</a>
					<ul class=\"sub-menu\">
						<li><a href=\"add_device.php\"><i class=\"fa fa-plus-square\"></i>Add Device</a></li>
						<li><a href=\"add_location.php\"><i class=\"fa fa-location-arrow\"></i>Add location</a></li>
						<li><a href=\"change_location.php\"><i class=\"fa fa-level-up\"></i>Change location</a></li>
						<li><a href=\"delete_device.php\"><i class=\"fa fa-minus-square\"></i>Delete device</a></li>
					</ul>
				</li>
				<li><a href=\"notification.php\"><i class=\"fa fa-bolt\"></i> Notification</a></li>
				<li class=\"collapsible active\">
					<a href=\"#\" onclick=\"return false;\"><i class=\"fa fa-gears\"></i>Settings</a>
					<ul class=\"sub-menu\">
						<li><a href=\"settings.php\"><i class=\"fa fa-exclamation\"></i>Change password</a></li>
						<li><a href=\"settings.php\"><i class=\"fa fa-tag\"></i>Change username</a></li>
						<li><a href=\"settings.php\"><i class=\"fa fa-user\"></i>Add user</a></li>
						<li><a href=\"settings.php\"><i class=\"fa fa-minus-square\"></i>Delete user</a></li>
					</ul>
				</li>
			</ul>
		</div> <!-- /sidebar -->

		<div id=\"content\" class=\"clearfix\">

			<div class=\"header\">
				
				<h1 class=\"page-title\">Settings</h1>
				<div class=\"stats\">
					<div class=\"stat\" id=\"st-visits\">
						<div class=\"st-chart\">
							<span id=\"stats_visits\" values=\"$ap_percent, $ap_percent_not\"></span><br>
							$ap_percent_not%
						</div>
						<div class=\"st-detail\">
							$not_access_points<br><span>APs not respond</span>
						</div>
					</div> <!-- /stat -->
					<div class=\"stat\" id=\"st-users\">
						<div class=\"st-chart\">
							<span id=\"stats_users\" values=\"$pi_percent,$pi_percent_not\"></span><br>
							$pi_percent_not%
						</div>
						<div class=\"st-detail\">
							$not_raspberry_pi<br><span>PIs not respond</span>
						</div>
					</div> <!-- /stat -->
					<div class=\"stat\" id=\"st-users\">
						<div class=\"st-chart\">
							<span id=\"stats_orders\" values=\"$loc_percent,$loc_percent_not\"></span><br>
							$loc_percent_not%
						</div>
						<div class=\"st-detail\">
							$no_location<br><span>Device loc. not set</span>
						</div>
					</div> <!-- /stat -->
					<button class=\"btn btn-green\" onClick=\"window.location.reload()\"><i class=\"fa fa-refresh\"></i> Update</button>
				</div> <!-- /stats -->

			</div> <!-- /header -->

			<div class=\"breadcrumbs\">
				<i class=\"fa fa-gears\"></i> Admin panel <i class=\"fa fa-caret-right\"></i> Settings
			</div>

			<div class=\"wrp clearfix\">
				");
				
				$notice = $_GET["notice"];
				if($notice){
					echo ("<div id=\"qn\">
							$notice
						</div>
						<div class=\"quick-nav\">
							$notice
						</div>");
				}
				
				echo ("
				<div class=\"fluid\">
				
				<div class=\"widget grid4\">
					<div class=\"widget-header\">
							<div class=\"widget-title\">
								<i class=\"fa fa-warning\"></i> Change Credentials
							</div>
						</div> <!-- /widget-header -->
					
					<div class=\"widget-content pad20f\">
						<i class=\"fa fa-exclamation\"></i> &nbsp; Change Password
						<form  action=\"change_password.php\" method=\"post\">
							<input type=\"password\" name=\"old_pass\" id=\"old_pass\" placeholder=\"Old Password\">
							<input type=\"password\" name=\"new_pass\" id=\"new_pass\"  placeholder=\"New Password\">
							<button class=\"btn btn-red\" type=\"submit\">Change Password</button>
						</form>
						
						<br></br>
						<form  action=\"change_username.php\" method=\"post\">
							<i class=\"fa fa-tag\"></i> &nbsp; Change username
							<input type=\"text\" name=\"new_user_name\" id=\"new_user_name\" placeholder=\"New Username\">
							<button class=\"btn btn-blue\" type=\"submit\">Change Username</button>
						</form>
					</div> <!-- /widget-content -->

				</div> <!-- /widget -->
				<div class=\"widget grid4\">
					<div class=\"widget-header\">
							<div class=\"widget-title\">
								<i class=\"fa fa-users\"></i> Add User
							</div>
						</div> <!-- /widget-header -->
					
					<div class=\"widget-content pad20f\">
						<form  action=\"add_user.php\" method=\"post\">
							<input type=\"text\" name=\"user_id\" id=\"user_id\" placeholder=\"User_ID\">
							<input type=\"text\" name=\"username\" id=\"username\" placeholder=\"Username\">
							<input type=\"text\" name=\"password\" id=\"password\" placeholder=\"Password\">
							<button class=\"btn btn-blue\" type=\"submit\">Add User</button>
						</form>
					</div> <!-- /widget-content -->

				</div> <!-- /widget -->
				<div class=\"widget grid4\">
					<div class=\"widget-header\">
							<div class=\"widget-title\">
								<i class=\"fa fa-minus-square\"></i> Delete User
							</div>
						</div> <!-- /widget-header -->
					
					<div class=\"widget-content pad20f\">
						<form  action=\"delete_user.php\" method=\"post\">
							<input type=\"password\" name=\"password\" id=\"password\" placeholder=\"Password\">
							List of users <br></br>
							<div class=\"custom-input\">
							 ");
								
								$qry_check = "select new_user_id from users_added where new_user_id like \"".$_SESSION['sess_user_id']."\"";
								$result_check = @mysql_query($qry_check);	
								
								$count_check = mysql_num_rows($result_check);
								
								if( $count_check == 0){
									$qry_users = "select new_user_id as user_id from users_added";
									$result_users = @mysql_query($qry_users);	
									
									while($row_user = mysql_fetch_assoc($result_users))
									{
										echo   "<li style=\"list-style-type: none;\"><input type=\"checkbox\" id=\"chk-{$row_user['user_id']}\" name=\"chk-{$row_user['user_id']}\"><label for=\"chk-{$row_user['user_id']}\">{$row_user['user_id']}</label></input></li>";
									}
								}
								else {
									$qry_users = "select new_user_id as user_id from users_added where user_id like \"".$_SESSION['sess_user_id']."\"";
									$result_users = @mysql_query($qry_users);	
									
									while($row_user = mysql_fetch_assoc($result_users))
									{
										echo   "<li style=\"list-style-type: none;\"><input type=\"checkbox\" id=\"chk-{$row_user['user_id']}\" name=\"chk-{$row_user['user_id']}\"><label for=\"chk-{$row_user['user_id']}\">{$row_user['user_id']}</label></input></li>";
									}
								}
								echo ("
							
							</div>
							<button class=\"btn btn-red\" type=\"submit\">Delete Users</button>
						</form>
						
					
					</div> <!-- /widget-content -->

				</div> <!-- /widget -->
			</div> <!-- fluid -->
			
		</div> <!-- /wrp -->

		</div> <!-- /content -->
		<footer class=\"footer\">
			© 2014 IIT Hyderabad. All rights reserved.  
		</footer>

	</div> <!-- /wrapper -->


	<script type=\"text/javascript\" src=\"js/prefixfree.min.js\"></script>
	<script type=\"text/javascript\" src='js/jquery-1.10.2.min.js'></script>
	<script type=\"text/javascript\" src=\"js/jquery-ui.js\"></script>
	<script type=\"text/javascript\" src=\"js/bootstrap.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/excanvas.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.flot.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.flot.resize.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.sparkline.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.hashchange.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.easytabs.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/toastr.min.js\"></script>

	<script type=\"text/javascript\">

		$(window).load(function(){
			$('#loading').fadeOut(1000);

			toastr.options = {
			  \"closeButton\": true,
			  \"debug\": false,
			  \"positionClass\": \"toast-bottom-right\",
			  \"onclick\": null,
			  \"showDuration\": \"300\",
			  \"hideDuration\": \"1000\",
			  \"timeOut\": \"5000\",
			  \"extendedTimeOut\": \"1000\",
			  \"showEasing\": \"swing\",
			  \"hideEasing\": \"linear\",
			  \"showMethod\": \"fadeIn\",
			  \"hideMethod\": \"fadeOut\"
			}
			
		// $(document).ready(function(){

			$('.collapsible > a').click(function(){
				$(this).parent().toggleClass('open');
				if( $(this).parent().siblings().hasClass('open') ){
					$(this).parent().siblings().removeClass('open');
				}
			return false;
			}) // Collapsible


			// -------------------------- SPARKLINE miniCHARTS -----------------------------//

			$(\"#stats_visits\").sparkline('html',{
		        type: 'pie',
		        sliceColors: ['#499ac7','transparent'],
		        offset:-90,
		        tooltipClassname:'tooltip-sp',
		        disableHighlight:true
		    });
		    $(\"#stats_users\").sparkline('html',{
		        type: 'pie',
		        sliceColors: ['#37343b','transparent'],
		        offset:-90,
		        tooltipClassname:'tooltip-sp',
		        disableHighlight:true 
		    });
		    $(\"#stats_orders\").sparkline('html',{
		        type: 'pie',
		        sliceColors: ['#83a854','transparent'],
		        offset:-90,
		        tooltipClassname:'tooltip-sp',
		        disableHighlight:true
		    });

		    
		 

		}) // Ready.
	</script>
</body>
</html>
");

}
?>