<?php
	//Include database connection details
	require_once('../config.php');

	session_start();
	
	$longval = $_POST['longval'];
	$latval = $_POST['latval'];
	$device_id = $_POST['selected_device_id'];
	
	if(isset($_SESSION['sess_user_id']) ){
		
		if($longval != null and $latval != null and $device_id != null){
			$qry_no_loc = "select device_id, essid, mac from device_info where (latitude is null or latitude = 0) and (longitude is null or longitude = 0) and device_id = $device_id";
			$result_no_loc = @mysql_query($qry_no_loc);	
		
			$no_location = mysql_num_rows($result_no_loc);
			
			if($no_location == 1){
				while($row = mysql_fetch_array($result_no_loc)) {
					$mac = substr($row['mac'], 0, -1);
				}
				$qry2 = "UPDATE device_info SET latitude=\"$latval\", longitude=\"$longval\" where mac like '$mac%'";
				$result2 = mysql_query($qry2);
				header('Location: notification.php?notice=Location updated');
				
			}
			else {
				header('Location: notification.php?notice=Location of selected device is already set by some other user.');
			}
		}
		else {
			header('Location: notification.php?notice=Please enter all the details.');
		}
	}
	else {
		header('Location: index.html');
	}
?> 
